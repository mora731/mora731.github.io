import csv
import random
import tkinter as tk
from datetime import datetime

from database import WordDatabase
from sprite import WordSprite


class TypingGameEngine:
    """
    【ゲームのコア部分】
    ゲーム画面、開始・再起動、スコア、下部インフォメーションの管理をします。
    """

    def __init__(self, root_window: tk.Tk):
        # ゲーム画面の初期化
        self.__root = root_window
        self.__root.title("タイピング練習ゲーム")  # タイトル
        self.__root.geometry("800x600")
        self.__root.resizable(False, False)

        # データベース読み込み用オブジェクト
        self.__db_manager = WordDatabase()
        self.__words_pool = []  # データベースから読み込んだすべての単語を保存するリスト

        # ゲームの基本データの初期化
        self.__score = 0  # スコア
        self.__lives = 3  # ライフ
        self.__is_playing = False  # 現在ゲームプレイ中かどうか
        self.__active_sprites = []  # 画面内を落ちているすべての単語オブジェクト
        self.__locked_sprite = None  # プレイヤーが現在タイピング中のターゲット単語
        self.__typed_buffer = ""  # ターゲット単語のうち、すでに入力があっている文字

        # タイマーのIDを記録する変数（後でキャンセルできるようにするため）
        self.__spawn_timer_id = None
        self.__game_timer_id = None

        # ゲーム画面を作成し、キーボード入力を関連付けます
        self.__build_gui()
        self.__root.bind("<Key>", self.__on_keypress)
        self.__sync_words_count()

    def __build_gui(self):
        """画面上部のステータスバー、中央のキャンバス、下部の案内バーを作成します"""

        # スコアとライフを表示する上部のバーを作成 (tk.Frameを使用)
        status_frame = tk.Frame(self.__root, padx=5, pady=5)
        status_frame.pack(fill=tk.X, side=tk.TOP)

        # 得点
        self.__score_label = tk.Label(
            status_frame, text="スコア: 0", font=("Segoe UI", 11)
        )
        self.__score_label.pack(side=tk.LEFT, padx=15)

        # 単語数
        self.__count_label = tk.Label(
            status_frame, text="単語数: 0", font=("Segoe UI", 11)
        )
        self.__count_label.pack(side=tk.LEFT, padx=15)

        # ライフ
        self.__lives_label = tk.Label(
            status_frame, text="残りライフ: 3", font=("Segoe UI", 11)
        )
        self.__lives_label.pack(side=tk.RIGHT, padx=15)

        # 分割線
        tk.Frame(self.__root, height=1, bg="#ccc").pack(fill=tk.X)

        # ゲームのメイン画面を作成
        self.__game_canvas = tk.Canvas(self.__root)
        self.__game_canvas.pack(fill=tk.BOTH, expand=True)

        # 分割線
        tk.Frame(self.__root, height=1, bg="#ccc").pack(fill=tk.X)

        # 一番下のアナウンス用メッセージバーを作成
        self.__info_label = tk.Label(
            self.__root,
            text="[ スペースキー ] を押してゲームをスタート",
            font=("Segoe UI", 12),
            anchor="center",
            pady=10,
        )
        self.__info_label.pack(fill=tk.X, side=tk.BOTTOM)

    def __sync_words_count(self):
        """データベースから単語を読み込み、画面の「単語数」の表示を更新します"""
        try:
            self.__words_pool = self.__db_manager.fetch_all_words()
            self.__count_label.config(text=f"単語数: {len(self.__words_pool)}")
        except Exception as e:
            self.__info_label.config(text=f"データベース読み込み失敗: {e}")

    def __start_session(self):
        """新しいゲームを開始します。データをすべて元に戻します"""
        self.__sync_words_count()
        if not self.__words_pool:
            self.__info_label.config(
                text="エラー：データベースが空のため、ゲームを開始できません！"
            )
            return

        if self.__spawn_timer_id:
            self.__root.after_cancel(self.__spawn_timer_id)
        if self.__game_timer_id:
            self.__root.after_cancel(self.__game_timer_id)
        self.__game_canvas.delete("all")

        self.__score = 0
        self.__lives = 3
        self.__is_playing = True
        self.__active_sprites = []
        self.__locked_sprite = None
        self.__typed_buffer = ""

        self.__score_label.config(text="スコア: 0")
        self.__lives_label.config(text="残りライフ: 3")
        self.__info_label.config(text="画面の単語を入力してください...")

        self.__run_spawn_loop()
        self.__run_game_loop()

    def __run_spawn_loop(self):
        """画面に新しい単語を次々と出現させるタイマーループです"""
        if not self.__is_playing:
            return

        if len(self.__active_sprites) < 6:
            random_word = random.choice(self.__words_pool)
            random_x = random.randint(60, 650)

            new_sprite = WordSprite(self.__game_canvas, random_word, random_x)
            self.__active_sprites.append(new_sprite)

        dynamic_interval = max(1000, 3000 - self.__score * 50)
        self.__spawn_timer_id = self.__root.after(
            dynamic_interval, self.__run_spawn_loop
        )

    def __run_game_loop(self):
        """画面を更新するメインループです"""
        if not self.__is_playing:
            return

        fall_speed = 1.0 + (self.__score * 0.02)
        expired_sprites = []

        for sprite in self.__active_sprites:
            sprite.update_position(fall_speed)

            if sprite.current_y > 460:
                expired_sprites.append(sprite)
                self.__lives -= 1

                if sprite == self.__locked_sprite:
                    self.__locked_sprite = None
                    self.__typed_buffer = ""
                    self.__info_label.config(
                        text="ターゲットが通り過ぎました！次の単語を狙いましょう"
                    )

        for sprite in expired_sprites:
            if sprite in self.__active_sprites:
                sprite.destroy()
                self.__active_sprites.remove(sprite)

        self.__score_label.config(text=f"スコア: {self.__score}")
        self.__lives_label.config(text=f"残りライフ: {self.__lives}")

        if self.__lives <= 0:
            self.__terminate_game()
            return

        self.__game_timer_id = self.__root.after(20, self.__run_game_loop)

    def __terminate_game(self):
        """ライフがなくなったときの終了処理です"""
        self.__is_playing = False
        self.__game_canvas.delete("all")

        self.__game_canvas.create_text(
            400,
            220,
            text="Game Over",
            fill="black",
            font=("Segoe UI", 32, "bold"),
        )
        self.__info_label.config(text="[ スペースキー ] を押してリトライ")

        # ファイル保存処理の呼び出し
        self.__save_game_results()

    def __save_game_results(self):
        """ゲーム結果をCSVに保存します"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        try:
            with open("score_history.csv", mode="a", newline="", encoding="utf-8") as f:
                writer = csv.writer(f)
                writer.writerow([current_time, self.__score])
        except Exception as e:
            print(f"CSV保存失敗: {e}")

        # ログをTXTに保存します
        try:
            with open("game_log.txt", mode="a", encoding="utf-8") as f:
                f.write(
                    f"[{current_time}] ゲーム終了 - 最終スコア: {self.__score} 点\n"
                )
        except Exception as e:
            print(f"テキストログ保存失敗: {e}")

    def __on_keypress(self, event: tk.Event):
        """プレイヤーがキーボードを押したときの処理を行います"""
        if event.keysym == "space" and not self.__is_playing:
            self.__start_session()
            return

        if not self.__is_playing or not (input_char := event.char.lower()).isalpha():
            return

        if self.__locked_sprite is None:
            for sprite in self.__active_sprites:
                if sprite.current_y <= 460 and sprite.word_string.startswith(
                    input_char
                ):
                    self.__locked_sprite = sprite
                    self.__typed_buffer = input_char
                    self.__sync_typing_ui()
                    break

        elif self.__locked_sprite in self.__active_sprites and len(
            self.__typed_buffer
        ) < len(self.__locked_sprite.word_string):
            target_word = self.__locked_sprite.word_string
            expected_char = target_word[len(self.__typed_buffer)]

            if input_char == expected_char:
                self.__typed_buffer += input_char
                self.__sync_typing_ui()

                if self.__typed_buffer.lower() == target_word.lower():
                    self.__score += 10
                    self.__locked_sprite.destroy()
                    self.__active_sprites.remove(self.__locked_sprite)
                    self.__locked_sprite = None
                    self.__typed_buffer = ""
                    self.__info_label.config(text="タイピング成功！")
            else:
                self.__info_label.config(
                    text=f"入力エラー！現在ロック中: {target_word}"
                )

    def __sync_typing_ui(self):
        """下部のタイピング状態を更新します"""
        if (
            not self.__locked_sprite
            or self.__locked_sprite not in self.__active_sprites
        ):
            self.__locked_sprite = None
            self.__typed_buffer = ""
            return

        target_str = self.__locked_sprite.word_string
        remaining_str = target_str[len(self.__typed_buffer) :]
        self.__info_label.config(
            text=f"入力中: {self.__typed_buffer} (残り: {remaining_str})"
        )
        self.__locked_sprite.render_highlight(self.__typed_buffer)


if __name__ == "__main__":
    window = tk.Tk()
    game_engine = TypingGameEngine(window)
    window.mainloop()
