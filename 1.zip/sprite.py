import tkinter as tk


class BaseSprite:
    """基底クラス"""

    def __init__(self, canvas: tk.Canvas, start_x: int, start_y: int):
        self._canvas = canvas
        self._x = start_x
        self._y = start_y

    def update_position(self, speed: float):
        """単語の移動"""

    def destroy(self):
        """削除"""


class WordSprite(BaseSprite):
    """
    単語スプライト、画面上を動く単語です。
    BaseSpriteから座標とキャンバス管理を継承しています。
    """

    def __init__(self, canvas: tk.Canvas, text: str, start_x: int, start_y: int = 20):
        # 親クラスのコンストラクタを呼び出し
        super().__init__(canvas, start_x, start_y)
        self.__text = text

        # 黒色の単語を描画します
        self.__base_text_id = self._canvas.create_text(
            self._x,
            self._y,
            text=self.__text,
            font=("Comic Sans Ms", 16),
            fill="black",
            anchor="w",
        )
        # プレイヤーが正しく入力した部分を赤色で重ねて表示します
        self.__highlight_text_id = self._canvas.create_text(
            self._x,
            self._y,
            text="",
            font=("Comic Sans Ms", 16),
            fill="red",
            anchor="w",
        )

    @property
    def word_string(self) -> str:
        return self.__text

    @property
    def current_y(self) -> int:
        return self._y

    def update_position(self, speed: float):
        """単語を落下させます"""
        self._y += speed
        self._canvas.coords(self.__base_text_id, self._x, self._y)
        self._canvas.coords(self.__highlight_text_id, self._x, self._y)

    def render_highlight(self, typed_part: str):
        """正しく入力された文字を赤色に変えます"""
        self._canvas.itemconfig(self.__highlight_text_id, text=typed_part)

    def destroy(self):
        """タイピング完了時、または落下時に画面から削除します"""
        self._canvas.delete(self.__base_text_id, self.__highlight_text_id)
