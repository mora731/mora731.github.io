import sqlite3


class WordDatabase:
    def __init__(self, db_name="typing_game.db"):
        # データベースのファイル名
        self.__db_name = db_name

    def fetch_all_words(self):
        # データベースを開いて、保存されている単語をすべて取り出します
        with sqlite3.connect(self.__db_name) as conn:
            rows = conn.cursor().execute("SELECT word FROM words").fetchall()
        # 有効性を判定し、値を返す
        return [row[0].strip() for row in rows if row and row[0]]
